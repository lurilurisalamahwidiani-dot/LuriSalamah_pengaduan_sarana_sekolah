-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 10 Apr 2026 pada 04.26
-- Versi server: 10.4.6-MariaDB
-- Versi PHP: 7.3.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `Pengaduan_sarana_sekolah`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tabel_admin`
--

CREATE TABLE `tabel_admin` (
  `id_admin` int(10) NOT NULL,
  `Ussername` varchar(11) NOT NULL,
  `Password` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tabel_admin`
--

INSERT INTO `tabel_admin` (`id_admin`, `Ussername`, `Password`) VALUES
(1, 'Admin', '123');

-- --------------------------------------------------------

--
-- Struktur dari tabel `Tabel_aspirasi`
--

CREATE TABLE `Tabel_aspirasi` (
  `id_aspirasi` int(10) NOT NULL,
  `Status` enum('Proses','Menunggu','Selesai') NOT NULL,
  `id_kategori` int(15) NOT NULL,
  `Feedback` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tabel_input`
--

CREATE TABLE `tabel_input` (
  `id_pelapor` int(10) NOT NULL,
  `Nama` varchar(12) NOT NULL,
  `Tanggal` date NOT NULL,
  `Kelas` varchar(10) NOT NULL,
  `Pengaduan` text NOT NULL,
  `Keterangan` text NOT NULL,
  `Lokasi` varchar(25) NOT NULL,
  `Status` varchar(20) NOT NULL,
  `Feedback` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tabel_input`
--

INSERT INTO `tabel_input` (`id_pelapor`, `Nama`, `Tanggal`, `Kelas`, `Pengaduan`, `Keterangan`, `Lokasi`, `Status`, `Feedback`) VALUES
(12, 'Luri', '2026-02-09', '12 rpl 1', 'Elektronik', 'Kipas angin rusak', 'SMK Sangkuriang 1 cimahi', 'diterima', 'Permintaan anda di Terima. '),
(26, 'Ulil', '2026-04-09', '12 rpl 1', 'Barang', 'Meja rusak', 'Kelas', 'proses', 'Permintaan anda di Terima. ');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tabel_kategori`
--

CREATE TABLE `tabel_kategori` (
  `id_kategori` int(11) NOT NULL,
  `ket_kategori` enum('Pendidikan','Pelayanan') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tabel_siswa`
--

CREATE TABLE `tabel_siswa` (
  `id_siswa` int(10) NOT NULL,
  `Ussername` varchar(10) NOT NULL,
  `Password` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tabel_siswa`
--

INSERT INTO `tabel_siswa` (`id_siswa`, `Ussername`, `Password`) VALUES
(1, 'Luri', '200308'),
(3, 'Ulil', '2008');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `tabel_admin`
--
ALTER TABLE `tabel_admin`
  ADD PRIMARY KEY (`id_admin`);

--
-- Indeks untuk tabel `Tabel_aspirasi`
--
ALTER TABLE `Tabel_aspirasi`
  ADD PRIMARY KEY (`id_aspirasi`);

--
-- Indeks untuk tabel `tabel_input`
--
ALTER TABLE `tabel_input`
  ADD PRIMARY KEY (`id_pelapor`);

--
-- Indeks untuk tabel `tabel_kategori`
--
ALTER TABLE `tabel_kategori`
  ADD PRIMARY KEY (`id_kategori`);

--
-- Indeks untuk tabel `tabel_siswa`
--
ALTER TABLE `tabel_siswa`
  ADD PRIMARY KEY (`id_siswa`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `tabel_admin`
--
ALTER TABLE `tabel_admin`
  MODIFY `id_admin` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `Tabel_aspirasi`
--
ALTER TABLE `Tabel_aspirasi`
  MODIFY `id_aspirasi` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `tabel_input`
--
ALTER TABLE `tabel_input`
  MODIFY `id_pelapor` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT untuk tabel `tabel_kategori`
--
ALTER TABLE `tabel_kategori`
  MODIFY `id_kategori` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `tabel_siswa`
--
ALTER TABLE `tabel_siswa`
  MODIFY `id_siswa` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
